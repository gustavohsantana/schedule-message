package com.api.desafio.controller;

import com.api.desafio.domain.Communication;
import com.api.desafio.dto.CommunicationDTO;
import com.api.desafio.service.CommunicationServiceImpl;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static org.springframework.http.ResponseEntity.ok;

@RestController
@RequestMapping("/communication")
@AllArgsConstructor
public class CommunicationController {

    @Autowired
    private CommunicationServiceImpl communicationService;

    @PostMapping(value = "/scheduleMessage")
    public ResponseEntity<Communication> scheduleMessage(@RequestBody CommunicationDTO communicationDTO) throws InterruptedException{
        return ok().body(communicationService.createMessage(communicationDTO));
    }

    @PutMapping(value = "/updateMessage")
    public ResponseEntity<Communication> updateMessage(@RequestBody Long id, CommunicationDTO communicationDTO) throws InterruptedException{
        return ok().body(communicationService.updateMessage(id, communicationDTO));
    }

    @DeleteMapping(value = "/updateMessage")
    public ResponseEntity<Communication> deleteMessage(@RequestBody Long id, CommunicationDTO communicationDTO) throws InterruptedException{
        return ok().body(communicationService.deleteMessage(id, communicationDTO));
    }

}
