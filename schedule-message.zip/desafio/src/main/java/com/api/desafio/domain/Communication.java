package com.api.desafio.domain;

import com.api.desafio.enums.CommunicationType;
import com.api.desafio.enums.Status;
import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;


@Entity
@Table(name = "COMMUNICATION")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Communication {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID")
    private Long id;

    @Column(name = "COM_TYPE")
    private CommunicationType communicationType;

    @Column(name = "STATUS")
    private Status status;

    @Column(name = "DESTINATARIO")
    private String destinatario;

    @Column(name = "DATA")
    private LocalDateTime data;

}
