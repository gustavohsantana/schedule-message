package com.api.desafio.dto;

import com.api.desafio.enums.CommunicationType;
import com.api.desafio.enums.Status;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class CommunicationDTO {

    private LocalDateTime data;
    private String destinatario;
    private CommunicationType type;
    private Status status;

}
