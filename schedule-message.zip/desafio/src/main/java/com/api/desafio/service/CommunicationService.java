package com.api.desafio.service;

import com.api.desafio.domain.Communication;
import com.api.desafio.dto.CommunicationDTO;
import com.api.desafio.enums.Status;
import com.api.desafio.repository.CommuncationRepository;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public interface CommunicationService {

    public Communication createMessage(CommunicationDTO communicationDTO);

    public Communication updateMessage(Long id, CommunicationDTO communicationDTO);

    public Communication deleteMessage(Long id, CommunicationDTO communicationDTO);
}
